<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title'); ?>||<?php echo app('translator')->getFromJson("general.title"); ?></title>

        <!-- Scripts -->
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>
        </script>

     <!--  <title>Flat Admin V.3 - Free flat-design bootstrap administrator templates</title> -->
  
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/vendor.css'); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/flat-admin.css'); ?>">

      <!-- Theme -->
      <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/theme/blue-sky.css'); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/theme/blue.css'); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/theme/red.css'); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/theme/yellow.css'); ?>">


    </head>

    <body>
        <div class="app app-default">
                <?php echo $__env->make('layouts.success-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="app-container">
                  <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php echo $__env->yieldContent('content'); ?>
                </div>
                <?php echo $__env->make('layouts.float-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
         <script type="text/javascript" src="<?php echo e('assets/js/vendor.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo e('assets/js/app.js'); ?>"></script>

    </body>

</html>