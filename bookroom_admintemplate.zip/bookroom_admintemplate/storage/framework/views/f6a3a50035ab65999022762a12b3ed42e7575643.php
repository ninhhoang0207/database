<?php $__env->startSection('title'); ?>
<?php echo app('translator')->getFromJson('hotel/general.title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row ">
  <div class="col-xs-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h2><?php echo app('translator')->getFromJson('hotel/general.title'); ?></h2>
        </div>
        <div class="panel-body">
          <table id="users-table" class="table table-bordered table-hover">
                <thead>
                    <th><?php echo app('translator')->getFromJson('hotel/general.id'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.ten'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.diachi'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.sdt'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.diachi'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.ngay_dk'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.thoihan_dk'); ?></th>
                    <th><?php echo app('translator')->getFromJson('hotel/general.chucnang'); ?></th>
                </thead>
                <tbody>
              
                </tbody>
            </table>
        </div>
    </div>
  </div>
</div>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>