<?php $__env->startSection('title'); ?>
<?php echo app('translator')->getFromJson('user/general.title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row ">
  <div class="col-xs-12">
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h2><?php echo app('translator')->getFromJson('user/general.title'); ?></h2>
    </div>
    <div class="panel-body">
        <table id="users-table" class="table table-bordered table-hover">
          <thead>
            <th>ID</th>
            <th>User name</th>
            <th>E-mail</th>
            <th>Phone</th>
            <th>Role</th>
            <th>Action</th>
          </thead>
          <tbody>
            
          </tbody>
      </table>
    </div>
 </div>
 </div>
 </div>
 
<?php $__env->startPush('scripts'); ?>
<script>
  $(function() {
      $('#users-table').DataTable({
          processing: true,
          serverSide: true,
          ajax: "<?php echo route('usersData'); ?>",
          columns: [
              { data: 'id', name: 'id' },
              { data: 'first_name', name: 'first_name' },
              { data: 'email', name: 'email' },
              { data: 'phone', name: 'phone' },
              { data: 'role', name: 'role' },
              { data: 'action', name: 'action' },
          ]
      });
  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>