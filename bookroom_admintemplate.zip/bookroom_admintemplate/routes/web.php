<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Admin
Route::group(['prefix' => 'admin'], function(){

	//users
	Route::get('', 'AdminUserController@index');
	Route::get('login','AdminController@index');
	Route::post('login','AdminController@postLogin')->name('postLogin');
	Route::get('register','AdminController@index');
	Route::post('register','AdminController@postRegister')->name('postRegister');
	Route::get('users-list','AdminUserController@index')->name('usersList');
	Route::get('users-data','AdminUserController@data')->name('usersData');
	Route::get('user-detail/{id}','AdminUserController@detail')->name('userShow');
	Route::get('user-del/{id}','AdminUserController@delete')->name('userDel');
	Route::post('user-update','AdminUserController@update')->name('userUpdate');

	//Quan ly nha nghi
});

Route::group(['prefix' =>	'hotel-manager'], function(){
	Route::get('','HotelController@index')->name('hotelList');
});

Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

