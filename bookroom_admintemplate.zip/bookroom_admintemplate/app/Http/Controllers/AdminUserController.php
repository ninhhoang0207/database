<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use User;
use Datatables;
use DB;
use Redirect;

class AdminUserController extends Controller
{
    //
    public function index(){
    	// print_r(Datatables::of(User::query())->make(true));die;
    	return view('admin.users.index');
    }

    public function detail($id){
    	$user = \App\User::where('id',$id)->first();
    	return view('admin.users.detail')->with('user',$user);
    }

    public function delete($id){
    	$del = DB::table('users')->where('id',$id)->delete();
    	if($del)
    		return Redirect::back()->with('messages','Delete Success');
    	return Redirect::back()->with('errors','Fail to delete');
    }

    public function data(){
    	$users = \App\User::query();
    	return Datatables::of($users)
    		->add_column('action', function($user){
                return "<a href=".route('userShow',$user->id).">Edit</a>"." <a href=".route('userDel',$user->id).">Delete</a>";
    		})->make(true);
    }
}
