<footer class="app-footer"> 
    <div class="row">
        <div class="col-xs-12">
            <div class="footer-copyright">
                Copyright © 2017 VidaApp
            </div>
        </div>
    </div>
</footer>