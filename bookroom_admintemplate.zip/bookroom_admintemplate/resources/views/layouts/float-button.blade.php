<div class="btn-floating" id="help-actions">
    <div class="btn-bg"></div>
    <button type="button" class="btn btn-default btn-toggle" data-toggle="toggle" data-target="#help-actions">
        <i class="icon fa fa-plus"></i>
        <span class="help-text">Shortcut</span>
    </button>
    <div class="toggle-content">
        <ul class="actions">
            <li><a href="/">Website</a></li>
            <li><a href="documentation">Documentation</a></li>
        </ul>
    </div>
</div>