@extends('layouts.default')
@section('title')
Detail
@endsection
@section('content')
<div class="panel panel-primary">
	{{Form::open(['route'=>'userUpdate'])}}
	<div class="panel-heading">
		<h2>User Detail</h2>
	</div>
	<div class="panel-body">
		<div class="col-md-4">
			<div class="form-group">
				<label for="email_name">E-mail *: </label>
				<input type="text" class="form-control" name="email_name" id="email_name" value="{{$user->email}}" \>
			</div>
			<div class="form-group">
				<label for="password">Password: </label>
				<input type="text" class="form-control" name="password" id="password"  \>
			</div>
			<div class="form-group">
				<label for="password_confirmation">Confirm-password: </label>
				<input type="text" class="form-control" name="password_confirmation" id="password_confirmation" value="" \>
			</div>
			<div class="form-group">
				<label for="role">Role: </label>
				<select class = "form-control col-md-3">
					<option>1</option>
					<option>1</option>
					<option>1</option>
					<option>1</option>
				</select>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label for="first_name">First name: </label>
				<input type="text" class="form-control" name="first_name" id="first_name" value="{{$user->first_name}}" \>
			</div>
			<div class="form-group">
				<label for="last_name">Last name: </label>
				<input type="text" class="form-control" name="last_name" id="last_name" value="{{$user->last_name}}" \>
			</div>
			
			<div class="form-group">
				<label for="address">Address: </label>
				<input type="text" class="form-control" name="address" id="address" value="{{$user->address}}" \>
			</div>
			<div class="form-group">
				<label for="phone">Phone number: </label>
				<input type="text" class="form-control" name="phone" id="phone" value="{{$user->phone}}" \>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label for="avatar">Avatar: </label>
				<img src="https://3.bp.blogspot.com/-W__wiaHUjwI/Vt3Grd8df0I/AAAAAAAAA78/7xqUNj8ujtY/s1600/image02.png" class="thumbnail" height="200px" width="200px">
			</div>
		</div>
	</div>
	<div class="panel-footer">
		<div class="form-group" id="button">
			<input type="submit" name="submit" value="Update" class="btn btn-success">
			<a href="{{route('usersList')}}" class="btn btn-danger">Back</a>
		</div>
	</div>
	{{Form::close()}}
</div>
@push('script')
<script type="text/javascript">
	$(document).ready(function(){
		$("#myform").validate({
		  submitHandler: function(form) {
		    $(form).submit();
		  }
	 	});
	});
</script>
@endpush
@endsection
