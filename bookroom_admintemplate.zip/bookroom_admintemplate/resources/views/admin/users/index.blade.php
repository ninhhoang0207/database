@extends('layouts.default')
@section('title')
@lang('user/general.title')
@endsection
@section('content')

<div class="row ">
  <div class="col-xs-12">
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h2>@lang('user/general.title')</h2>
    </div>
    <div class="panel-body">
        <table id="users-table" class="table table-bordered table-hover">
          <thead>
            <th>ID</th>
            <th>User name</th>
            <th>E-mail</th>
            <th>Phone</th>
            <th>Role</th>
            <th>Action</th>
          </thead>
          <tbody>
            
          </tbody>
      </table>
    </div>
 </div>
 </div>
 </div>
 
@push('scripts')
<script>
  $(function() {
      $('#users-table').DataTable({
          processing: true,
          serverSide: true,
          ajax: "{!! route('usersData') !!}",
          columns: [
              { data: 'id', name: 'id' },
              { data: 'first_name', name: 'first_name' },
              { data: 'email', name: 'email' },
              { data: 'phone', name: 'phone' },
              { data: 'role', name: 'role' },
              { data: 'action', name: 'action' },
          ]
      });
  });
</script>
@endpush
@endsection