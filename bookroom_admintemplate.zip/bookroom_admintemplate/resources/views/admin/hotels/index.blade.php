@extends('layouts.default')
@section('title')
@lang('hotel/general.title')
@endsection
@section('content')

<div class="row ">
  <div class="col-xs-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h2>@lang('hotel/general.title')</h2>
        </div>
        <div class="panel-body">
          <table id="users-table" class="table table-bordered table-hover">
                <thead>
                    <th>@lang('hotel/general.id')</th>
                    <th>@lang('hotel/general.ten')</th>
                    <th>@lang('hotel/general.diachi')</th>
                    <th>@lang('hotel/general.sdt')</th>
                    <th>@lang('hotel/general.diachi')</th>
                    <th>@lang('hotel/general.ngay_dk')</th>
                    <th>@lang('hotel/general.thoihan_dk')</th>
                    <th>@lang('hotel/general.chucnang')</th>
                </thead>
                <tbody>
              
                </tbody>
            </table>
        </div>
    </div>
  </div>
</div>
 

@endsection