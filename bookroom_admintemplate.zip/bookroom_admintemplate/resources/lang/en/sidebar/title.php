<?php
	return [
		'danh-sach-nguoi-dung'		=>		'Danh sách người dùng',
		'quan-ly-nha-nghi'			=>		'Quản lý nhà nghỉ',
		'danh-sach-nha-nghi'		=>		'Danh sách nhà nghỉ',
		'chuc-nang'					=>		'Chức năng',
	];