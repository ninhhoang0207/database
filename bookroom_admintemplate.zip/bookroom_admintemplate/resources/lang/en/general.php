<?php

	return [
		'title'			=>			'Đặt phòng online',
	];