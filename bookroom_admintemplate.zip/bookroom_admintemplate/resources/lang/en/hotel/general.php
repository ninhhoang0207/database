<?php 
	return [
		'title'		=>		'Danh sách nhà nghỉ',
		'id'		=>		'STT',
		'ten'		=>		'Tên nhà nghỉ',
		'diachi'	=>		'Địa chỉ',
		'sdt'		=>		'Số điện thoại',
		'ngay_dk'	=>		'Ngày đăng ký',
		'thoihan_dk'=>		'Thời hạn đăng ký',
		'chucnang'	=>		'Chức năng',
	];